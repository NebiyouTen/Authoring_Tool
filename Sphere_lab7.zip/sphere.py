import sys
sys.path.append("~/vr/lib")
import numpy as np
import math
import H_builders as Hx
import bmp_io_c

class Sphere(object) :
    def __init__(self, TBA, t, image_name, radius) :
        self.__t = np.copy( t )
        self.__radius = np.copy(radius)
        self.__TBA = np.copy( TBA )
        self.__in = image_name
        self.__R, self.__C, self.__imgdat = bmp_io_c.input_bmp_c(self.__in)
        self.__wcl = np.zeros( [self.__R*self.__C, 7], np.float32 )
        self.__H = Hx.bw_build(TBA, t)

        __theta = -np.pi
        __phi = -np.pi/2
        i = 0

        for x in range(self.__C):
            for y in range(self.__R):
                __rgbValues = self.__imgdat[:, y, x]
                bodyX = self.__radius*np.cos(__phi)*np.sin(__theta)
                bodyY = self.__radius*np.sin(__phi)
                bodyZ = self.__radius*np.cos(__phi)*np.cos(__theta)

                __worldCordinates = np.matmul(self.__H, np.asarray( [bodyX, bodyY, bodyZ, 1] ))

                self.__wcl[i, :] = [__worldCordinates[0], __worldCordinates[1], __worldCordinates[2], 1, \
                __rgbValues[0], __rgbValues[1], __rgbValues[2]]
               
                __phi += (np.pi/2)/self.__R

                i += 1
	        __theta += np.pi/self.__C

        
    def get_R(self) :
        return self.__R

    def get_C(self) :
        return self.__C

    def get_wc_list(self) :
        return np.copy( self.__wcl )